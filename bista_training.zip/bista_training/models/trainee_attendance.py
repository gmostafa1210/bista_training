# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class TraineeAttendance(models.Model):
    _name = 'bista.trainee.attendance'
    _description = 'Bista Trainee Class'
    _rec_name = 'batch_ids'


    date = fields.Date('Date', readonly='True') 
    batch_ids = fields.Many2one('bista.trainee.batch', string='Batch')
    attendance_line = fields.One2many('bista.trainee.attendance.line', 'attendance_id', string='Trainees')


class TraineeAttendanceLine(models.Model):
    _name = 'bista.trainee.attendance.line'
    _description = 'Bista Trainee Class'


    
    attendance_id = fields.Many2one('bista.trainee.attendance', string='Batch')
    trainee_ids = fields.Many2one('bista.trainee')
    trainee_name = fields.Char('Trainee Name', related='trainee_ids.name')
    trainee_sequence_id = fields.Char('Trainee ID', related='trainee_ids.trainee_id')
    morning = fields.Boolean('Morning')
    evening = fields.Boolean('Evening')



class TraineeAttendanceRecord(models.Model):
    _name = 'bista.trainee.attendance.record'


    date = fields.Date('Date')
    batch_id = fields.Many2one('bista.trainee.batch', string='Batch')
    trainee_ids = fields.Many2one('bista.trainee')
    seq_id = fields.Char('Trainee ID', related='trainee_ids.trainee_id')



    



    