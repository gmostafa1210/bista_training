# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class Home(models.Model):
    _name = 'bista.home'
    _description = 'Bista Trainee Class'