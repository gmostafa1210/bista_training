# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError
import random
from datetime import date

class Trainee(models.Model):
    _name = 'bista.trainee'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Bista Trainee Class'


    name = fields.Char(string='Name', compute='_get_full_name')
    first_name = fields.Char(string='First Name', required=True)
    last_name = fields.Char(string='Last Name')
    trainee_id = fields.Char(string='Trainee ID', required=True, copy=False, readonly=True, index=True, default=lambda self: _('New'))
    emp_code = fields.Char(string='EMP Code')
    personal_email_id = fields.Char(string='Personal Email ID', required=True)
    linkedin_profile_url= fields.Char(string='Linkedin Profile URL')
    gender= fields.Selection([
                            ('male', 'Male'),
                            ('female', 'Female'),
                            ], default='male', required=True)
    dob = fields.Date('DOB')
    date_of_joining = fields.Date('Date of Joining')
    location = fields.Many2one('bista.location', string='Location')
    designation = fields.Many2one('bista.trainee.role', string='Designation')
    profile_image = fields.Image('Profile Image')
    state = fields.Selection([
                            ('new', 'New'),
                            ('training', 'Training'),
                            ('rejected', 'Rejected'),
                            ('employee', 'Employeed'),
                            ], default='new', string='Status')
    employee = fields.Many2one('hr.employee', string='Employee')   
    batch_id = fields.Many2one('bista.trainee.batch')
    related_user = fields.Many2one('res.users', string="Related User")
  
    _sql_constraints = [
                        ('personal_email_id_uniq', 'unique(personal_email_id)', 'This EMAIL already exists !'),
                        ('trainee_id_uniq', 'unique(trainee_id)', 'Trainee already exists !'),
                        ]

    def _get_full_name(self):
        for item in self:
            if item.first_name and not item.last_name:  
                item.last_name=""          
                item.name =  "%s %s" %(item.first_name, item.last_name)
            item.name =  "%s %s" %(item.first_name, item.last_name)
            

    @api.constrains('dob')
    def _check_dob(self):
        for record in self:
            if record.dob and record.dob >= date.today():
                raise UserError(_("Invalid DOB!"))


    @api.model
    def create(self, vals):
        if vals.get('trainee_id', _('New')) == _('New'):
            vals['trainee_id'] = self.env['ir.sequence'].next_by_code('bista.trainee.sequence') or _('New')
        return super(Trainee, self).create(vals)

    def action_create_employee(self):
        self.env['hr.employee'].create(dict(
            name=self.name,
            image_1920 = self.profile_image,
            job_title= self.designation.name,
            private_email = self.personal_email_id,
            gender = self.gender,
        ))
        for i in self:
            i.state= 'employee'



class TraineeBatch(models.Model):
    _name = 'bista.trainee.batch'
    _description = 'Bista Trainee Class'


    name = fields.Char('Batch Name')  
    start_date = fields.Date('Start Date') 
    end_date = fields.Date('End Date') 

    trainees = fields.One2many('bista.trainee', 'batch_id', string='Trainees')


class TraineeRole(models.Model):
    _name = 'bista.trainee.role'
    _description = 'Bista Trainee Role Class'


    name = fields.Char(string='Name', required=True)
    sequence = fields.Integer(string='Sequence')
