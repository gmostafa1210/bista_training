# -*- coding: utf-8 -*-

from odoo import fields, models, api, _

class Trainer(models.Model):
    _name = 'bista.trainer'
    _description = 'Bista Trainee Management System'

    name = fields.Char(string='Name', compute='_get_full_name')
    first_name = fields.Char(string='First Name', required=True)
    last_name = fields.Char(string='Last Name')
    profile_image = fields.Binary('Profile Image')

    def _get_full_name(self):
        for item in self:
            if item.first_name and not item.last_name:  
                item.last_name=""          
                item.name =  "%s %s" %(item.first_name, item.last_name)
            item.name =  "%s %s" %(item.first_name, item.last_name)