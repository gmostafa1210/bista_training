# -*- coding: utf-8 -*-

from odoo import fields, models, api, _




class TrainingSubject(models.Model):
    _name = 'bista.training.subject'
    _description = 'Bista Training Subject Class'


    name = fields.Char(string='Name', required=True)
    description = fields.Html(string='Description')
    topics = fields.One2many('bista.training.topics', 'subject', string='Topics')
    trainers = fields.Many2many('bista.trainer', string='Trainers')


class TrainingTopics(models.Model):
    _name = 'bista.training.topics'
    _description = 'Bista Training Topics Class'


    name = fields.Char(string='Name', required=True)
    subject = fields.Many2one('bista.training.subject', string='Subject')


class TrainingStages(models.Model):
    _name = 'bista.training.stages'
    _description = 'Bista Training Stages Class'


    name = fields.Char(string='Name')
    available_on_batch = fields.Boolean('Available on Batch')
    available_on_training_record = fields.Boolean('Available on Training Record')
    status = fields.Selection([
        ('draft', 'Draft'),
        ('progress', 'Progress'),
        ('done', 'Done'),
    ])
