from odoo import models, fields, api, _
from datetime import datetime

class TakeAttendance(models.TransientModel):
    _name = 'bista.take.attendance'

    batch_id = fields.Many2one('bista.trainee.batch', string='Batch')
    date = fields.Date('Date')

    def take_attendance(self):
        vals = {
            'batch_ids': self.batch_id.id,
            # 'date': datetime.today(),
            'date': self.date
        }
        new_attendance_form_id = self.env['bista.trainee.attendance'].create(vals)  # After clicking the "Take Attendance" menu then it will create new attendance sheet

        trainees_individual_batch = self.batch_id.trainees
        for trainee in trainees_individual_batch:
            data = {
                'attendance_id': new_attendance_form_id.id,
                'trainee_ids': trainee.id,
            }
            self.env['bista.trainee.attendance.line'].create(data)  #  After creating Attendance sheet this line creates the trainee list batchwise

        for item in trainees_individual_batch:           
            data = {
                'trainee_ids': item.id,
                'batch_id': self.batch_id.id,
                # 'date': datetime.today(),
                'date': self.date
            }
            self.env['bista.trainee.attendance.record'].create(data)  # This model contains all the single record thus we can filter by trainee, batch and date

        return {
            'name': "Attendance",
            'type': "ir.actions.act_window",
            'res_model': "bista.trainee.attendance",
            'view_mode': "form",
            'res_id': new_attendance_form_id.id,
        }




class TraineeAttendanceFilterByBatchOrTrainee(models.TransientModel):
    _name = 'bista.trainee.attendance.filter.batch.traineeid'

    trainee_id = fields.Char('Trainee ID')
    batch_id = fields.Many2one('bista.trainee.batch', string='Batch')

    def attendance_filter_by_batch_or_traineeid(self):

        return {
            'name': "Attendance",
            'type': "ir.actions.act_window",
            'res_model': "bista.trainee.attendance.record",
            'view_mode': "tree",
            'domain': ['|', ('batch_id', '=', self.batch_id.id), ('seq_id', '=', self.trainee_id)]
        }



class AttendanceFilterByBatch_Trainee_Date(models.TransientModel):
    _name = 'bista.trainee.attendance.filter.batch.traineeid.date'

    batch_id = fields.Many2one('bista.trainee.batch', string='Batch')
    trainee_id = fields.Char('Trainee ID')
    start_date = fields.Date('From')
    end_date = fields.Date('To')

    def attendance_filter_by_batch_traineeid_start_to_end_date(self):
        return {
            'name': "Attendance",
            'type': "ir.actions.act_window",
            'res_model': "bista.trainee.attendance.record",
            'view_mode': "tree",
            'domain': ['&', ('batch_id', '=', self.batch_id.id), ('seq_id', '=', self.trainee_id), ('date', '>=', self.start_date), ('date', '<=', self.end_date)]
        }