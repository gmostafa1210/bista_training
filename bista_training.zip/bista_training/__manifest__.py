
{
    'name' : 'Bista Training',
    'version' : '1.0',
    'summary': '',
    'sequence': 1,
    'description': 'Bista Training Management System',
    'category': '',
    'website': 'https://www.odoo.com',
    'depends' : [
        'base',
        'mail',
        'hr',
        'contacts',
    ],
    'data': [
        # Security
        'security/bista_model_access_groups.xml',
        'security/bista_model_access_record_rules.xml',
        'security/ir.model.access.csv',

        # Data
        'data/sequence.xml',

        # Views
        'views/home.xml',
        'views/trainee.xml',
        'views/trainer.xml',
        'views/training.xml',
        'views/location.xml',
        'views/trainee_attendance.xml',

        # Wizard
        'wizard/attendance.xml',
        'wizard/menu.xml'
        
     
    ],
    'demo': [],
    'qweb': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
